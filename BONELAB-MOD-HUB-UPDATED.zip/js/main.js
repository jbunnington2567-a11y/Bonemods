(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-nav');
  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const open = menuButton.getAttribute('aria-expanded') !== 'true';
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      nav.classList.toggle('is-open', open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open navigation');
    }));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        nav.classList.remove('is-open');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Open navigation');
      }
    });
  }

  const search = document.querySelector('#resource-search');
  const cards = [...document.querySelectorAll('.resource-card')];
  const count = document.querySelector('#result-count');
  const empty = document.querySelector('#empty-state');
  const grid = document.querySelector('#resource-grid');
  function filterResources() {
    const query = (search.value || '').trim().toLocaleLowerCase();
    let visible = 0;
    cards.forEach(card => {
      const content = `${card.dataset.search || ''} ${card.textContent}`.toLocaleLowerCase();
      const match = content.includes(query);
      card.hidden = !match;
      if (match) visible++;
    });
    count.textContent = `${visible} ${visible === 1 ? 'RESOURCE' : 'RESOURCES'}`;
    empty.hidden = visible !== 0;
    grid.hidden = visible === 0;
  }
  if (search) {
    search.addEventListener('input', filterResources);
    document.addEventListener('keydown', event => {
      if (event.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) {
        event.preventDefault();
        search.focus();
      }
    });
  }
})();
