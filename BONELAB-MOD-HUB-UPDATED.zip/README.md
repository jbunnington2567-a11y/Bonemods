# BONELAB MOD HUB

A responsive, static community resource website for BONELAB. Built with plain HTML, CSS and JavaScript; no backend, build step, package manager or framework is required.

## Publish on GitHub Pages

1. Create a new GitHub repository (or open the repository you want to use).
2. Upload the **contents** of this folder, keeping `index.html`, `css/`, `js/` and `assets/` at the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your publishing branch (usually `main`) and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. Open the Pages URL shown in repository settings.

No base-path changes are needed: all local paths are relative and work on a project Pages URL.

## Edit the website

- `index.html` contains the page content, navigation and resource URLs.
- `css/styles.css` controls the monochrome visual design and responsive layouts.
- `js/main.js` contains live resource filtering and mobile navigation.
- `assets/` contains the favicon plus the user-supplied CX File Explorer, GitHub, Shizuku, Fusion, LemonLoader logos and BONELAB promotional images.

To add or remove a resource, duplicate or edit an `.resource-card` in `index.html`. Keep its `data-search` terms useful so the live search can find it. Use a verified official project URL for the card link.

## Branding and artwork note

The supplied images have been integrated as local assets: the header uses the supplied BONELAB logo (`assets/bonelab-logo.jpeg`), and the hero uses the BONELAB promotional gameplay image (displayed in grayscale to retain the site's monochrome treatment), and the Fusion, LemonLoader, Shizuku, CX File Explorer, mod.io and Thunderstore cards use their supplied logo artwork. The GitHub mark is used only as a platform indicator for the Go To Settings repository, not as that project's logo. The BONELAB hero is user-supplied promotional artwork. Keep these image files in `assets/` when publishing. The user-supplied BoneLib artwork is used on the BoneLib resource card.

The Meta Quest destination is the verified BONELAB store listing:
https://www.meta.com/en-gb/experiences/bonelab/4215734068529064/

ThunderstoreModAssistant is linked to its verified BONELAB Thunderstore package by notnotnotswipez:
https://thunderstore.io/c/bonelab/p/notnotnotswipez/ThunderstoreModAssistant/

## Notes

- The site is an unofficial community resource and includes the requested Stress Level Zero disclaimer.
- External links open in a new tab with `noopener noreferrer`.
- The resource search matches both resource names and descriptions.
- Google Fonts are an optional external typography enhancement; system sans-serif fallbacks remain in place if unavailable.
